@WebServlet("/filme")
public class FilmeServlet extends HttpServlet {

    private List<Filme> filmes;

    @Override
    public void init() throws ServletException {
        filmes = new ArrayList<>();
        filmes.add(new Filme("Velozes e Furiosos 10", "Ação", 2022, "velozesefuriosos10.jpg"));
        filmes.add(new Filme("O Portal Secreto", "Comédia", 2014, "oportalsecreto.jpg"));
        filmes.add(new Filme("Rambo Até o Fim", "Ação", 2019, "ramboateofim.jpg"));
    }

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String termoPesquisa = req.getParameter("pesquisa");

        resp.setContentType("text/HTML");
        PrintWriter out = resp.getWriter();

        out.println("<h2>Resultados da Pesquisa:</h2>");

        filmes.stream()
                .filter(filme -> filme.getNome().toLowerCase().contains(termoPesquisa.toLowerCase()))
                .forEach(filme -> {
                    out.println("<div>");
                    out.println(String.format("<h3>%s</h3>", filme.getNome()));
                    out.println(String.format("<img src='resources/images/%s' alt='%s' width='200'/>", filme.getImagem(), filme.getNome()));
                    out.println("</div>");
                });

        out.close();
    }
}
