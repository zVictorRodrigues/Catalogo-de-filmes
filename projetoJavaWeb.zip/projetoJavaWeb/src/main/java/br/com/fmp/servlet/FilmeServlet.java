package br.com.fmp.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import br.com.fmp.modelo.filme;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/filme")
public class FilmeServlet extends HttpServlet {
	
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		filme velozesEFuriosos7 = new filme("Velozes e Furiosos 7", "Ação", 2015);
        filme poderosoChefao = new filme("O Poderoso Chefão", "Drama", 1972);
        filme matrix = new filme("Matrix", "Ficção Científica", 1999);
        filme titanic = new filme("Titanic", "Romance", 1997);
        filme starWars = new filme("Star Wars: Episódio IV - Uma Nova Esperança", "Ficção Científica", 1977);
        filme senhorDosAneis = new filme("O Senhor dos Anéis: A Sociedade do Anel", "Fantasia", 2001);
        filme forrestGump = new filme("Forrest Gump", "Drama", 1994);
        filme interestelar = new filme("Interestelar", "Ficção Científica", 2014);
        filme panteraNegra = new filme("Pantera Negra", "Ação", 2018);
        filme infiltrados = new filme("Os Infiltrados", "Policial", 2006);

       
        ArrayList<filme> filmes = new ArrayList<filme>();

       
        filmes.add(velozesEFuriosos7);
        filmes.add(poderosoChefao);
        filmes.add(matrix);
        filmes.add(titanic);
        filmes.add(starWars);
        filmes.add(senhorDosAneis);
        filmes.add(forrestGump);
        filmes.add(interestelar);
        filmes.add(panteraNegra);
        filmes.add(infiltrados);
        
        String genero = req.getParameter("genero");
        
        resp.setContentType("text/HTML");
		PrintWriter out = resp.getWriter();
		
		out.println("<h2>Lista de Filmes utilizando Servlets:</h2>");
        out.println("<ol>");
        
        filmes.stream().filter(filme -> filme.getGenero().toUpperCase().equals(genero.toUpperCase())).forEach(filme -> {
        	out.println(String.format("<li> Nome: %s", filme.getNome()));
        	out.println(String.format(" Genero: %s", filme.getGenero()));
        	out.println(String.format(" Ano: %s </li>", filme.getAnoLancamento()));
        });
        out.close();
	}
}
